# Toggl Dashboard

## What is this

This is a dashboard that I am building to get more insights about the work I do and the time I spend doing things.


## Why

I feel like the insights toggl gives aren't that much, and wished I could see more of where I am spending my time and energy. Also it makes a cool project!

![](https://github.com/bigpappathanos-web/Toggl-Dashboard/blob/main/bin/images/Peek%202020-10-12%2013-26.gif?raw=true )

Work in progress by Atharva Arya.

